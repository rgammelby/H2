﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Baggagesorteringssystem.Data_Access
{
    internal class Destination
    {
        private int _destinationId;
        private string _city;
        private string _country;
        private string _airportCode;
        private List<Destination> _destinationList = new List<Destination>();

        public int DestinationId { get { return _destinationId; } }
        public string City { get { return _city; } }
        public string Country { get { return _country; } }
        public string AirportCode { get { return _airportCode; } }
        public List<Destination> DestinationList { get { return _destinationList; } }

        private List<Destination> GetDestinations()
        {
            Connection cs = new Connection();
            var dt = cs.RetrieveData("destinations");

            List<Destination> destination = new List<Destination>();

            foreach (DataColumn col in dt.Columns)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    Destination a = new Destination((int)dr[0], (string)dr[1], (string)dr[2], (string)dr[3]);
                    destination.Add(a);
                }
            }

            return destination;
        }

        public Destination()
        {
            _destinationList = GetDestinations();
        }

        public Destination(int destinationId, string city, string country, string airportCode)
        {
            _destinationId = destinationId;
            _city = city;
            _country = country;
            _airportCode = airportCode;
        }
    }
}
